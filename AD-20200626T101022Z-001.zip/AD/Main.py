from project import app

app.run(port=8080, threaded=True)
